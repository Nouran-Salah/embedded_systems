/*
 * main.c
 *
 *  Created on: Sep 8, 2023
 *      Author: USER
 */

#include <stdio.h>


int main (){

	printf("sadas");



	return 0;
}




